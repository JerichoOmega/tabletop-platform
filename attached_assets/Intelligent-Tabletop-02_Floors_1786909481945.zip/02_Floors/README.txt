Intelligent Tabletop canonical visual asset upload

Cobblestone showcase contains the approved floor-family variants. Large Floor / Room Tile is included separately.

Approved assets represented by this category:
- Cobblestone Classic V1
- Cobblestone Cleaner V1
- Cobblestone Overgrown V1
- Cobblestone Ruined V1
- Dungeon Stone V1
- Large Floor / Room Tile V1
