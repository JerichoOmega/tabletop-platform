Intelligent Tabletop canonical visual asset upload

Recovered showcase sheet containing the canonical four miniature pieces. Preserve as source artwork; do not crop/regenerate unless the existing asset pipeline requires it.

Approved assets represented by this category:
- Human Fighter
- Human Spellcaster
- Goblin Warrior
- Orc Warrior
