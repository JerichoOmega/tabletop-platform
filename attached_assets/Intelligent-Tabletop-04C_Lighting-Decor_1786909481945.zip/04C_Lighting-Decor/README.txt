Intelligent Tabletop visual asset upload. These are recovered approved visual sheets. Preserve source artwork; do not regenerate.
Reference/alternate sheets are not included in these canonical upload packages.
